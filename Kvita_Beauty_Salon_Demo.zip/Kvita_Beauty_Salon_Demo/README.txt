KVITA BEAUTY SALON — DEMO WEBSITE
===================================

Files:
- index.html  : all website sections and content
- style.css   : responsive desktop/tablet/mobile styling
- script.js   : mobile navigation, booking form, WhatsApp enquiry setup

HOW TO OPEN:
1. Extract the ZIP.
2. Open the folder in VS Code.
3. Open index.html in a browser, or use VS Code Live Server.
4. Internet is required for Google Fonts and the online Unsplash demo photos.

IMPORTANT BEFORE SHOWING TO A REAL CUSTOMER:
1. Open script.js and replace SALON_WHATSAPP_NUMBER with the salon's real WhatsApp number,
   including country code, digits only. India example: 919876543210.
2. Replace the generic salon location, phone, hours and about text in index.html.
3. Replace inspiration photos with Kvita Beauty Salon's own work/photos and confirm rights/permission.
4. Test the booking form on mobile. It opens WhatsApp with the enquiry pre-filled; the visitor must press Send.
5. This is a front-end demo. It does not store bookings in a database.

All navigation and call-to-action buttons point to relevant sections. The booking form validates required fields.
